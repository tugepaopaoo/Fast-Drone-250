rosbag record --tcpnodelay /mavros/battery /mavros/setpoint_raw/attitude /traj_start_trigger
